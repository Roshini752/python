import openpyxl
#import pandas as pd
#import xlrd
#from PIL import Image 
from openpyxl_image_loader import SheetImageLoader

import smtplib
import imghdr

#loading the Excel File and the sheet
pxl_doc = openpyxl.load_workbook('data.xlsx')
sheet = pxl_doc['Sheet1']


#calling the image_loader
image_loader = SheetImageLoader(sheet)
#rows = list(sheet.rows)



#get the image (put the cell you need instead of 'A1')
#for r in range(1,5):
r=Temp
image = image_loader.get(f'A{r}')
image.save('C:\ProgramData\Jenkins\.jenkins\workspace\py_task\image_name.png')
r=+1
