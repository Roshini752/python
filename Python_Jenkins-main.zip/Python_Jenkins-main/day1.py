#this is python
print("roshini")
print("........")
"""

roshini
python
thundersody
"""
v2 =9;
if(v2<10):
    print("less")
