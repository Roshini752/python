import openpyxl
from openpyxl_image_loader import SheetImageLoader

#loading the Excel File and the sheet
pxl_doc = openpyxl.load_workbook('data.xlsx')
sheet = pxl_doc['Sheet1']


#calling the image_loader
image_loader = SheetImageLoader(sheet)


#get the image (put the cell you need instead of 'A1')
for r in range(1,4):
    image = image_loader.get(f'A{r}')



#saving the image
    image.save('C:\ProgramData\Jenkins\.jenkins\workspace\py_task\image_name.png')
    files = ['image_name.png']
    import smtplib
    import imghdr
    from email.message import EmailMessage

    Sender_Email = "164c5roshini@gmail.com"
    Reciever_Email = "164c5roshini@gmail.com"
    #Password = input('Enter your email account password: ')
    Password ="roshiny752"
    
    newMessage = EmailMessage()                         
    newMessage['Subject'] = "Check out the Image" 
    newMessage['From'] = Sender_Email                   
    newMessage['To'] = Reciever_Email                   
    newMessage.set_content('Image attached!') 

#files = ['test.png','test2.png']

    for file in files:
        with open(file, 'rb') as f:
            image_data = f.read()
            image_type = imghdr.what(f.name)
            image_name = f.name
        newMessage.add_attachment(image_data, maintype='image', subtype=image_type, filename=image_name)

    with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
    
        smtp.login(Sender_Email, Password)              
        smtp.send_message(newMessage) 
