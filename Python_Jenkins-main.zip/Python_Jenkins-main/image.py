import openpyxl
#import pandas as pd
#import xlrd
from PIL import ImageGrab 
from openpyxl_image_loader import SheetImageLoader

import smtplib
import imghdr

#loading the Excel File and the sheet
pxl_doc = openpyxl.load_workbook('data.xlsx')
sheet = pxl_doc['Sheet1']


#calling the image_loader
image_loader = SheetImageLoader(sheet)
#rows = list(sheet.rows)


m = 5
#get the image (put the cell you need instead of 'A1')
for r in range(1,5):

    image = image_loader.get(f'A{r}')
    #image.copy()
    #image = ImageGrab.grabclipboard()

    image.save('C:\ProgramData\Jenkins\.jenkins\workspace\py_task\images\image_name'+str(r)+'.png')
    
