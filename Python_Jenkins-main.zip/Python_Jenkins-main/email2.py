import smtplib
import imghdr
from email.message import EmailMessage

Sender_Email = "roshinipeyyala752@gmail.com"
Reciever_Email = "roshinipeyyala752@gmail.com"
Password = "rOsHiNy1"

newMessage = EmailMessage()                         
newMessage['Subject'] = "Check out the Image" 
newMessage['From'] = Sender_Email                   
newMessage['To'] = Reciever_Email                   
newMessage.set_content('Image attached!') 
files=[]
for i in range(1,5):
    
    files.append("C:\ProgramData\Jenkins\.jenkins\workspace\py_task\image_name"+str(i)+".png")

for file in files:
    with open(file, 'rb') as f:
        image_data = f.read()
        image_type = imghdr.what(f.name)
        image_name = f.name
    newMessage.add_attachment(image_data, maintype='image', subtype=image_type, filename=image_name)

with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
    
    smtp.login(Sender_Email, Password)              
    smtp.send_message(newMessage)  
